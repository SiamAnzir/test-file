import {useState , useEffect , useRef} from "react";
import Navbar from "../../components/Navbar/Navbar.jsx";
import Footer from "../../components/Footer/Footer.jsx";
import SingleBlogCard from "../../components/SingleBlogCard/SingleBlogCard.jsx";
import MostPopularBlogs from "../../components/MostPopularBlogs/MostPopularBlogs.jsx";
const Home = () => {
    const [blogList, setBlogList] = useState([]);
    const [page, setPage] = useState(1);
    const [hasMore, setHasMore] = useState(true);
    const loaderRef = useRef(null);
    const blogLimit = 5 ;

    useEffect(() => {
        const fetchBlogList = async () => {
            const response = await fetch(
                `${import.meta.env.VITE_REACT_APP_BASE_URL}/blogs?page=${page}&limit=${blogLimit}`
            );
            const data = await response.json();

            if (data.blogs.length === 0) {
                setHasMore(false);
            } else {
                setBlogList((prevBlogs) => [
                    ...prevBlogs,
                    ...data.blogs,
                ]);
                setPage((prevPage) => prevPage + 1);
            }
        };

        const onIntersection = (items) => {
            const loaderItem = items[0];

            if (loaderItem.isIntersecting && hasMore) {
                fetchBlogList();
            }
        };

        const observer = new IntersectionObserver(onIntersection);

        if (observer && loaderRef.current) {
            observer.observe(loaderRef.current);
        }

        // cleanup
        return () => {
            if (observer) observer.disconnect();
        };
    }, [hasMore, page]);

    return(
        <>
            <Navbar/>
            <section>
                <div className="container">
                    <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
                        <div className="space-y-3 md:col-span-5">
                            {blogList.map((blog) => (
                                <SingleBlogCard key={blog.id} blog={blog}/>
                            ))}

                            {hasMore && <div ref={loaderRef}>Loading more Blogs...</div>}
                        </div>

                        <div className="md:col-span-2 h-full w-full space-y-5">
                            <MostPopularBlogs/>
                            <div className="sidebar-card">
                                <h3
                                    className="text-slate-300 text-xl lg:text-2xl font-semibold"
                                >
                                    Your Favourites ❤️
                                </h3>

                                <ul className="space-y-5 my-5">
                                    <li>
                                        <h3
                                            className="text-slate-400 font-medium hover:text-slate-300 transition-all cursor-pointer"
                                        >
                                            How to Auto Deploy a Next.js App on
                                            Ubuntu from GitHub
                                        </h3>
                                        <p className="text-slate-600 text-sm">
                                            #tailwindcss, #server, #ubuntu
                                        </p>
                                    </li>

                                    <li>
                                        <h3
                                            className="text-slate-400 font-medium hover:text-slate-300 transition-all cursor-pointer"
                                        >
                                            How to Auto Deploy a Next.js App on
                                            Ubuntu from GitHub
                                        </h3>
                                        <p className="text-slate-600 text-sm">
                                            #tailwindcss, #server, #ubuntu
                                        </p>
                                    </li>

                                    <li>
                                        <h3
                                            className="text-slate-400 font-medium hover:text-slate-300 transition-all cursor-pointer"
                                        >
                                            How to Auto Deploy a Next.js App on
                                            Ubuntu from GitHub
                                        </h3>
                                        <p className="text-slate-600 text-sm">
                                            #tailwindcss, #server, #ubuntu
                                        </p>
                                    </li>

                                    <li>
                                        <h3
                                            className="text-slate-400 font-medium hover:text-slate-300 transition-all cursor-pointer"
                                        >
                                            How to Auto Deploy a Next.js App on
                                            Ubuntu from GitHub
                                        </h3>
                                        <p className="text-slate-600 text-sm">
                                            #tailwindcss, #server, #ubuntu
                                        </p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <Footer/>
        </>
    )
}

export default Home