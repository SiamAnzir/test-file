import './App.css'
import {BrowserRouter , Routes , Route} from "react-router-dom";
import Home from "./pages/Home/Home.jsx";
import Login from "./pages/Auth/Login.jsx";
import Register from "./pages/Auth/Register.jsx";
import Profile from "./pages/Profile/Profile.jsx";
import CreateBlog from "./pages/CreateBlog/CreateBlog.jsx";
import SingleBlogPage from "./pages/Blog/SingleBlog.jsx";
function App() {
  return (
    <>
        <BrowserRouter>
            <Routes>
                <Route element={<Home/>} path="/" exact/>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/createBlog" element={<CreateBlog />} />
                <Route path="/blog/:id" element={<SingleBlogPage />} />
            </Routes>
        </BrowserRouter>
    </>
  )
}

export default App
