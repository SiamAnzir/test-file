import {useEffect, useState} from "react";

const MostPopularBlogs = () => {
    const [popularBlogs , setPopularBlogs] = useState([])
    useEffect(() => {
        const fetchMostPopularBlogs = async () => {
            const response = await fetch(
                `${import.meta.env.VITE_REACT_APP_BASE_URL}/blogs/popular?limit=4`
            );
            const data = await response.json();

            setPopularBlogs(data)
        };

        fetchMostPopularBlogs()
    },[])
    console.log(popularBlogs)
    return (
        popularBlogs && popularBlogs.blogs && popularBlogs.blogs.length ?
        <div className="sidebar-card">
            <h3
                className="text-slate-300 text-xl lg:text-2xl font-semibold"
            >
                Most Popular 👍️
            </h3>

            <ul className="space-y-5 my-5">
                {popularBlogs.blogs.map((blog) => (
                    <li key={blog.id}>
                        <h3
                            className="text-slate-400 font-medium hover:text-slate-300 transition-all cursor-pointer"
                        >
                            {blog.title}
                        </h3>
                        <p className="text-slate-600 text-sm">
                            by <a href="./profile.html">{blog.author.firstName} {blog.author.lastName}</a>
                            <span>·</span> {blog.likes.length} Likes
                        </p>
                    </li>
                ))}
            </ul>
        </div> : <></>
    )
}

export default MostPopularBlogs;