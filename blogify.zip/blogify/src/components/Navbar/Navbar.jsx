import logo from "../../assets/logo.svg";
import searchIcon from "../../assets/icons/search.svg";
import "./Navbar.css"
import {Link} from "react-router-dom";
import SearchResult from "./SearchResult.jsx";
import {useState} from "react";
import {createPortal} from "react-dom";

const Navbar = () => {
    const [searchbarState, setSearchbarState] = useState(false);
    return (
        <header>
            <nav className="container">
                <div>
                    <Link to="/">
                        <img className="w-32" src={logo} alt="lws"/>
                    </Link>
                </div>

                <div>
                    <ul className="flex items-center space-x-5">
                        <li>
                            <Link to="/createBlog"
                               className="bg-indigo-600 text-white px-6 py-2 md:py-3 rounded-md hover:bg-indigo-700 transition-all duration-200"
                            >
                                Write
                            </Link>
                        </li>
                        <li>
                            <div
                                onClick={() => setSearchbarState(!searchbarState)}
                                className="flex items-center gap-2 cursor-pointer"
                            >
                                <img
                                    src={searchIcon}
                                    alt="Search"
                                />
                                <span>Search</span>
                            </div>
                        </li>
                        <li>
                            <Link
                                to="/login"
                                className="text-white/50 hover:text-white transition-all duration-200"
                            >
                                Login
                            </Link>
                        </li>
                        <li className="flex items-center">
                            <div className="avater-img bg-orange-600 text-white">
                                <span className="">S</span>
                            </div>

                            <Link to="/profile">
                                <span className="text-white ml-2">Siam Anzir</span>
                            </Link>
                        </li>
                    </ul>
                </div>
            </nav>
            {searchbarState &&
                createPortal(
                    <SearchResult setSearchbarState={setSearchbarState} />,
                    document.body
                )}
        </header>
    )
}

export default Navbar;