/* eslint-disable react/prop-types */
import { useState } from 'react';
import threeDot from '../../assets/icons/3dots.svg';
import deleteIcon from '../../assets/icons/delete.svg';
import edit from '../../assets/icons/edit.svg';

const SingleBlogCard = ({blog}) => {
    const [actionButton, setActionButton] = useState(false);
    return (
        <div className="blog-card">
            <img className="blog-thumb" src={blog.thumbnail} alt={blog.author.firstName} />
            <div className="mt-2 relative">
                <a href="./single-blog.html">
                    <h3 className="text-slate-300 text-xl lg:text-2xl">
                        {blog.title}
                    </h3>
                </a>
                <p className="mb-6 text-base text-slate-500 mt-1">
                    {blog.content}
                </p>

                <div className="flex justify-between items-center">
                    <div className="flex items-center capitalize space-x-2">
                        {/*<div className="avater-img bg-indigo-600 text-white">*/}
                        {/*    <span className="">S</span>*/}
                        {/*</div>*/}
                        <img className="blog-thumb" src={blog.author.avatar} alt={blog.author.lastName}/>

                        <div>
                            <h5 className="text-slate-500 text-sm">{blog.author.firstName} {blog.author.lastName}</h5>
                            <div className="flex items-center text-xs text-slate-700">
                                <span>{blog.createdAt}</span>
                            </div>
                        </div>
                    </div>

                    <div className="text-sm px-2 py-1 text-slate-700">
                    <span>{blog.likes.length} Likes</span>
                    </div>
                </div>
                <div className="absolute right-0 top-0">
                    <button
                        onClick={() => {
                            setActionButton(!actionButton);
                        }}
                    >
                        <img src={threeDot} alt="3dots of Action" />
                    </button>
                    {actionButton && (
                        <div className="action-modal-container">
                            <button className="action-menu-item hover:text-lwsGreen">
                                <img src={edit} alt="Edit" />
                                Edit
                            </button>
                            <button className="action-menu-item hover:text-red-500">
                                <img src={deleteIcon} alt="Delete" />
                                Delete
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default SingleBlogCard;